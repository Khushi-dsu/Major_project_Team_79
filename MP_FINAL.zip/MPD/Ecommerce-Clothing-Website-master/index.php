<?php
$active = "Home";
include("functions.php");
include("header.php");

?>

<script>
window.onload = function() {
  const message = "Welcome to Vision Vogue. Would you like to shop or go to cart?";
  const speech = new SpeechSynthesisUtterance(message);
  window.speechSynthesis.speak(speech);

  // Speech Recognition
  let recognition = new window.webkitSpeechRecognition();
  recognition.lang = 'en-US';
  recognition.continuous = true;
  recognition.interimResults = false;

  recognition.onresult = function(event) {
    const result = event.results[0][0].transcript.toLowerCase();
    if (result.includes('shop')) {
      window.location.href = 'shop.php';
    } else if (result.includes('cart page')) {
      window.location.href = 'login.php';
    } else {
      const sorryMessage = "Sorry, could you please repeat?";
      const sorrySpeech = new SpeechSynthesisUtterance(sorryMessage);
      window.speechSynthesis.speak(sorrySpeech);
      // Restart recognition
      recognition.stop();
      recognition = new window.webkitSpeechRecognition();
      recognition.lang = 'en-US';
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.start();
    }
  };

  recognition.start();
};
</script>



<section class="hpg">
    <div class="container2">
        <!-- Replace '#' with the actual link -->
    </div>
</section>



<section class="hpg">
<div class="container2">
        <!-- Replace '#' with the actual link -->

    </div>
</section>
<div class="product-large set-bg" data-setbg="img/hpg.jpg">
                    <a href="shop.php?cat_id=2" class="shoplink" >Shop now</a>
                </div>


<!-- Banner Section Begin -->


<!-- Women Banner Section Begin -->

<section class="women-banner spad">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3">
                <div class="product-large set-bg" data-setbg="img/women-large.jpg">
                    <h2>Women’s</h2>
                    <a href="shop.php?cat_id=2">Discover More</a>
                </div>
            </div>
            <div class="col-lg-8 offset-lg-1">
                <div class="filter-control">
                    <h3> Hot Products </h3>
                </div>
                <div class="product-slider owl-carousel">

                    <?php
                    getWProduct();
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Man Banner Section Begin -->

<section class="man-banner spad">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8">
                <div class="filter-control">
                    <h3> Hot Products </h3>
                </div>
                <div class="product-slider owl-carousel">
                    <?php
                    getMProduct();
                    ?>

                </div>
            </div>
            <div class="col-lg-3 offset-lg-1">
                <div class="product-large set-bg m-large" data-setbg="img/men-large.jpg">
                    <h2>Men’s</h2>
                    <a href="shop.php?cat_id=1">Discover More</a>
                </div>
            </div>
        </div>
    </div>
</section>
<img src="banner-1.png" width="50px" height="100px" alt="jhgjhfht">
<!-- Footer -->

<?php
include('footer.php');


if (isset($_GET['stat'])) {

    echo "
        <script>
                bootbox.alert({
                    message: 'Welcome! You are logged in.',
                    backdrop: true
                });
        </script>";
}
?>


</body>

</html>