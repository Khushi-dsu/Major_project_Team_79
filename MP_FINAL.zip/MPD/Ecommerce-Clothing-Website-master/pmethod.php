<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment Selection</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-color: #f2f2f2;
    }

    .container {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 500px;
        height: 400px;
    }

    .payment-option {
        margin-bottom: 20px;
    }

    .payment-option label {
        display: inline;
        margin-bottom: 8px;
    }
    ul{
        list-style: none;
        margin-top: 10%;
      }
    li{
        margin-top: 10%;
    }

    .payment-option input[type="radio"] {
        margin-right: 8px;
    }

    .payment-option img {
        max-width: 100px;
        margin-top: 5px;
    }

    .btn {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 4px;
        cursor: pointer;
        margin-left: 35%;
        margin-top: 10%;
    }
</style>
</head>
<body>
<div class="container">
    <h2>Select Payment Method</h2>
    <ul>
    <li>
        <div class="payment-option">
        <input type="radio" id="debit_card" name="payment_method" value="debit_card">
        <label for="debit_card">Debit Card</label>
        <!-- You can add a debit card icon here if you have one -->
        </div>
    </li>
    <li>
    <div class="payment-option">
        <input type="radio" id="upi" name="payment_method" value="upi">
        <label for="upi">UPI</label>
        <!-- You can add a UPI icon here if you have one -->
    </div>
    </li>
    <li>
    <div class="payment-option">
        <input type="radio" id="cash_on_delivery" name="payment_method" value="cash_on_delivery">
        <label for="cash_on_delivery">Cash on Delivery</label>
        <!-- You can add a cash on delivery icon here if you have one -->
    </div>
    </li>
    </ul>
    <button class="btn">Proceed to Payment</button>
</div>
</body>
</html>