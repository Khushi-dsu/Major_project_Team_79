<?php
$active = "Paymentmode";
include("functions.php");
include("header.php");
?>

<!-- Breadcrumb Section Begin -->


<div class="breacrumb-section">
    <div class="containerp">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text product-more">
                    <a href="index.php"><i class="fa fa-home"></i> Home</a>
                    <a href="shop.php">Shop</a>
                    <a href="check-out.php">Check Out</a>
                    <span>Select Payment Method</span>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Section End -->
<div class="outer-container">
    <div class="pay-container" style="padding: 20px; background-color: #f2f2f2; border-radius: 10px;">
        <h2>Select Payment Method</h2>
        <ul>
            <li>
                <div class="payment-option">
                <input type="radio" id="debit_card" name="payment_method" value="debit_card">
                <label for="debit_card">Debit Card</label>
                <!-- You can add a debit card icon here if you have one -->
                </div>
            </li>
            <li>
                <div class="payment-option">
                    <input type="radio" id="upi" name="payment_method" value="upi">
                    <label for="upi">UPI</label>
                    <!-- You can add a UPI icon here if you have one -->
                </div>
            </li>
            <li>
                <div class="payment-option">
                    <input type="radio" id="cash_on_delivery" name="payment_method" value="cash_on_delivery">
                    <label for="cash_on_delivery">Cash on Delivery</label>
                    <!-- You can add a cash on delivery icon here if you have one -->
                </div>
            </li>
        </ul>
        <button class="paybtn" onclick="proceedToPayment()">Proceed to Payment</button>
    </div>
</div>

<?php include('footer.php'); ?>


</body>
</html>


<script>
function proceedToPayment() {
    var selectedPaymentMethod = document.querySelector('input[name="payment_method"]:checked');
    if (selectedPaymentMethod !== null) {
        var paymentPage;
        switch (selectedPaymentMethod.value) {
            case "debit_card":
                paymentPage = "cardpayment.php";
                break;
            case "upi":
                paymentPage = "upipayment.php";
                break;
            case "cash_on_delivery":
                paymentPage = "ordersuccess.php";
                break;
            default:
                alert("Invalid payment method selected.");
                return;
        }
        window.location.href = paymentPage;
    } else {
        alert("Please select a payment method.Card, UPI or cash on deliver");
    }
}



window.onload = function() {
    // Function to speak the initial prompt
    function speakPrompt(promptText) {
        var synth = window.speechSynthesis;
        var utterThis = new SpeechSynthesisUtterance(promptText);
        synth.speak(utterThis);
    }

    // Function to handle user's speech response
    function handleSpeechResponse(event) {
        var speechResult = event.results[0][0].transcript.trim().toLowerCase();
        var selectedPaymentMethod;

        // Check if user's speech matches any payment method
        switch (speechResult) {
            case "card":
            case "debit card":
                selectedPaymentMethod = "debit_card";
                break;
            case "upi":
                selectedPaymentMethod = "upi";
                break;
            case "cash":
            case "cash on delivery":
                selectedPaymentMethod = "cash_on_delivery";
                break;
            default:
                alert("Invalid payment method selected.");
                return;
        }

        // Navigate to the appropriate payment page
        navigateToPayment(selectedPaymentMethod);
    }

    // Function to navigate to payment page based on selected method
    function navigateToPayment(selectedPaymentMethod) {
        var paymentPage;
        switch (selectedPaymentMethod) {
            case "debit_card":
                paymentPage = "cardpayment.php";
                break;
            case "upi":
                paymentPage = "upipayment.php";
                break;
            case "cash_on_delivery":
                paymentPage = "ordersuccess.php";
                break;
            default:
                alert("Invalid payment method selected.");
                return;
        }
        window.location.href = paymentPage;
    }

    // Speak the initial prompt when the page loads
    speakPrompt("Please tell your method of payment, card, UPI or Cash on deliver");

    // Create a SpeechRecognition object
    var recognition = new webkitSpeechRecognition();

    // Configure SpeechRecognition
    recognition.lang = "en-US";
    recognition.continuous = true;
    recognition.interimResults = false;

    // Add event listeners
    recognition.onresult = handleSpeechResponse;

    // Start recognition
    recognition.start();
}





</script>

