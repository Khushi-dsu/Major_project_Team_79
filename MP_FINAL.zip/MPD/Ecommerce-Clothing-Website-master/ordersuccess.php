<?php
$active = "ordersuccess";
include("functions.php");
include("header.php");
?>

<!-- Breadcrumb Section Begin -->

<div class="breacrumb-section">
    <div class="containerp">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text product-more">
                    <a href="index.php"><i class="fa fa-home"></i> Home</a>
                    <a href="shop.php">Shop</a>
                    <a href="payment_mode.php">Select Payment Method</a>
                    <span>Order Placed</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="pay-container">
    <h2 class="Order_success">Order Placed Successfully!</h2>
</div>

<?php include('footer.php'); ?>

<script>





window.onload = function() {
    var message = new SpeechSynthesisUtterance('Your order is placed successfully, please press j to shop again');
    window.speechSynthesis.speak(message);
};

document.addEventListener('keydown', function(event) {
    if (event.key === 'j') {
        window.location.href = 'shop.php';
    }
});

   



</script>


</body>
</html>