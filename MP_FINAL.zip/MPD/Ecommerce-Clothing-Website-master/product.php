<?php
$active = "Product";
include("db.php");
include("functions.php");
include('header.php');
?>
<div style="overflow: hidden;">
    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text product-more">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <a href="shop.php">Shop</a>
                        <span>Details</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Product Shop Section Begin -->
    <section class="product-shop spad page-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="filter-widget">
                        <h4 class="fw-title">Categories</h4>
                        <ul class="filter-catagories">
                            <?php

                            getCat();

                            ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="row">
                        <?php

                        getProd();
                        addCart();

                        ?>



                        <form action='product.php?add_cart=<?php if (isset($_GET['product_id'])) {
                                                                $product_id = $_GET['product_id'];
                                                                echo $product_id;
                                                            } ?>' method='post'>

                            <div class="form-group">
                                <!-- form-group Begin -->
                                <div class='quantity'>
                                    <div class='pro-qty'>
                                        <input type='text' value='1' name="product_qty">
                                    </div>
                                </div>
                            </div><!-- form-group Finish -->

                            <div class="form-group">
                                <!-- form-group Begin -->
                                <div class='pd-size-choose'>
                                    <div class='sc-item'>
                                        <input type='radio' id='sm-size' class="form-control" name='size' value="Small" required novalidate>
                                        <label for='sm-size'>s</label>
                                    </div>
                                    <div class='sc-item'>
                                        <input type='radio' id='md-size' class="form-control" name='size' value="Medium">
                                        <label for='md-size'>m</label>
                                    </div>
                                    <div class='sc-item'>
                                        <input type='radio' id='lg-size' class="form-control" name='size' value="Large">
                                        <label for='lg-size'>l</label>
                                    </div>
                                    <div class='sc-item'>
                                        <input type='radio' id='xl-size' class="form-control" name='size' value="XL">
                                        <label for='xl-size'>xl</label>
                                    </div>
                                </div>
                                <p id="msg"></p>
                            </div><!-- form-group Finish -->
                            <?php if ($_SESSION['customer_email'] == 'unset') {
                                echo "<a id='carting' href='login.php' class='btn primary-btn pd-cart' style='margin-top: 20px;'> Add to cart</a>";
                            } else {
                                echo "<button class='btn primary-btn pd-cart' id='cartbtn' style='margin-top: 20px;'> Add to cart</button>";
                            }
                            ?>
                        </form>

                    </div>
                </div>
            </div>
        </div>
</div>

</section>


<div class="related-products spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <h2>More like this</h2>
                </div>
            </div>
        </div>

        <div class="row">

            <?php

            relatedProducts();
            ?>

        </div>
    </div>
</div>
</div>

<?php
include('footer.php');
?>

<script>
    // Function to announce product details using speech synthesis and then start listening for user's voice input
function announceProductDetailsAndListen() {
    // Extract product details from the page
    const productTitle = document.querySelector('.pd-title h3').textContent;
    const productDesc = document.querySelector('.pd-desc').textContent;
    const productPrice = document.querySelector('.pd-price').textContent;

    // Construct the message
    const message = `The product is ${productDesc} ${productTitle} and the price is ${productPrice}. Please tell your preferred size. Small, Medium, Large, or Extra Large`;

    // Using SpeechSynthesis API to speak out the message
    const utterance = new SpeechSynthesisUtterance(message);
    speechSynthesis.speak(utterance);

    // Start listening for user's voice input after the message is read out
    utterance.onend = function() {
        startListeningForSize();
    };
}

// Call the function to announce product details and start listening when the window loads
window.onload = announceProductDetailsAndListen;

// Function to start listening for user's voice input for size selection
function startListeningForSize() {
    // Initialize SpeechRecognition API
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = true;

    // Start listening
    recognition.start();

    // Event listener for when speech recognition results are available
    recognition.onresult = function(event) {
        const size = event.results[0][0].transcript.trim().toLowerCase();

        // Check if the recognized size matches any of the available sizes
        const availableSizes = ['small', 'medium', 'large', 'extra large'];
        if (availableSizes.includes(size)) {
            // Set the value of the radio button corresponding to the recognized size
            document.querySelector(`input[value='${size.charAt(0).toUpperCase() + size.slice(1)}']`).checked = true;
            
            // Hide the message if size is recognized
            document.getElementById('msg').innerHTML = '';

            // Inform the user to press 'j' key to proceed
            const pressJMessage = `Press 'j' key to proceed.`;
            const pressJUtterance = new SpeechSynthesisUtterance(pressJMessage);
            speechSynthesis.speak(pressJUtterance);

            // Stop listening
            recognition.stop();
        } else {
            // Inform the user to try again if the recognized size is not valid
            document.getElementById('msg').innerHTML = "<span class='alert alert-danger'>Invalid size. Please try again.</span>";

            // Start listening again
            startListeningForSize();
        }
    };
}

document.addEventListener('keydown', function(event) {
    // Check if the pressed key is 'j' or 'J'
    if (event.key === 'j' || event.key === 'J') {
        // Check if the user is logged in or not to determine which button to click
        if ('<?php echo $_SESSION['customer_email']; ?>' === 'unset') {
            // If user is not logged in, click the 'Add to cart' link
            document.getElementById('carting').click();
        } else {
            // If user is logged in, click the 'Add to cart' button
            document.getElementById('cartbtn').click();
        }
    }
});


</script>



</body>

</html>