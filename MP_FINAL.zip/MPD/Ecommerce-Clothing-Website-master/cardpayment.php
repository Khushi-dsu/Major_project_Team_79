<?php
$active = "Paymentmode";
include("functions.php");
?>

<div class="card-container">
    <div class="right">
        <h3>PAYMENT</h3>
        <form>
            Accepted Card <br>
            <img src="img/card1.png" width="100">
            <img src="img/card2.png" width="50">
            <br><br>

            <label for="c1">Credit card number</label>
            <input type="text" id="c1" name="card_number" placeholder="card number">

            <label for="c2">Expiry month</label>
            <input type="text" id="c2" name="exp_month" placeholder=" Month">

            <div class="zip">
                <label for="c3">Expiry year</label>
                <input type="text" id="c3" name="exp_year" placeholder="Year">

                <label for="c4">CVV</label>
                <input type="text" id="c4" name="cvv" placeholder="CVV" class="labelcvv">
            </div>
        </form>
        <button id="proceedButton">Proceed to Pay</button>
    </div>
</div>
<?php

include("header.php");
?>
<?php include('footer.php'); ?>

<script>

function announceCartPage() {
        const message1 = "press tab to enter your card details";
        // Using SpeechSynthesis API to speak out the message
        const utterance1 = new SpeechSynthesisUtterance(message1);
        speechSynthesis.speak(utterance1);
    }

    // Call the function when the page loads
    window.onload = announceCartPage;





    const speechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new speechRecognition();

    recognition.lang = 'en-US';
    recognition.interimResults = false;

    const speak = (text) => {
        const synth = window.speechSynthesis;
        const utterance = new SpeechSynthesisUtterance(text);
        synth.speak(utterance);
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const lastElement = document.activeElement;

        if (lastElement.tagName === 'INPUT') {
            lastElement.value = transcript;
        }
    };

    recognition.onend = () => {
        console.log('Speech recognition ended.');
    };

    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('focus', () => {
            speak(`Please enter ${input.placeholder} and press tab`);
        });
    });

    document.getElementById('proceedButton').addEventListener('click', () => {
        let details = '';

        document.querySelectorAll('label').forEach((label, index, labels) => {
            const input = document.getElementById(label.getAttribute('for'));
            details += `${label.textContent}: ${input.value}. `;

            // Check if it's the last label, if so, append instruction to press 'j' key
            if (index === labels.length - 1) {
                details += "Press 'j' key to proceed.";
            }
        });

        speak(details);
    });

    document.body.addEventListener('click', () => {
        recognition.start();
    });

    // Adding event listener for the 'j' key to navigate to order.php
    document.addEventListener('keydown', (event) => {
        if (event.key === 'j') {
            window.location.href = 'ordersuccess.php';
        }
    });
</script>

</body>
</html>
