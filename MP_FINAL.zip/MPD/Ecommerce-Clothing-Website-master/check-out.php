<?php
$active = "Checkout";
include('db.php');
include("functions.php");
include("header.php");
?>


<!-- Breadcrumb Section Begin -->
<div class="breacrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text product-more">
                    <a href="index.php"><i class="fa fa-home"></i> Home</a>
                    <a href="shop.php">Shop</a>
                    <span>Check Out</span>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Section End -->

<!-- Shopping Cart Section Begin -->
<section class="checkout-section spad">
    <div class="container">
        <form class="checkout-form">
            <div class="row">

                <div class="col-lg-6" <?php if (!($_SESSION['customer_email'] == 'unset')) {
                                            echo "style = 'margin: 0 auto'";
                                        } ?>>
                    <div class="checkout-content">
                        <a href="shop.php" class="content-btn">Continue Shopping</a>
                    </div>
                    <div class="place-order">
                        <h4>Your Order</h4>
                        <div class="order-total">
                            <ul class="order-table">
                                <li>Products <span>Total</span></li>
                                <?php
                                // Include the HTML 'li' tag from function.php
                                global $db;
                                $ip_add = getRealIpUser();
                                $c_id = $_SESSION['customer_email'];

                                $get_items = "select * from cart where c_id = '$c_id' ORDER BY date DESC";
                                $run_items = mysqli_query($db, $get_items);

                                if (mysqli_num_rows($run_items) == 0) {
                                    echo  "
                                        <li class='fw-normal' style='text-align:center;font-weight:bold;font-size:larger;color:#fe4231'>No Items in Cart</li>
                                    ";
                                } else {
                                    while ($row_items = mysqli_fetch_array($run_items)) {
                                        $p_id = $row_items['products_id'];
                                        $pro_qty = $row_items['qty'];

                                        $get_item = "select * from products where products_id = '$p_id' ORDER BY date DESC";
                                        $run_item = mysqli_query($db, $get_item);

                                        while ($row_item = mysqli_fetch_array($run_item)) {
                                            $pro_name = $row_item['product_title'];
                                            $pro_price = $row_item['product_price'];
                                            $pro_total_p = $pro_price * $pro_qty;
                                        }

                                        echo "
                                            <li class='fw-normal'> $pro_qty $pro_name<span>$pro_total_p</span></li>
                                        ";
                                    }
                                }
                                ?>
                                <li class="fw-normal">Subtotal <span><?php total_price(); ?></span></li>
                                <li class="total-price">Total <span><?php total_price(); ?></span></li>
                            </ul>
                            <form action="check-out.php" method="post">
                                <div class="order-btn">
                                    <a id="placeOrderBtn" href="payment_mode.php" class="site-btn place-btn">Place Order</a>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
        </form>
    </div>
</section>
<!-- Shopping Cart Section End -->


<?php
include('footer.php');
?>



<script>
    // Function to announce product details when the page loads
    function announceProductDetails() {
        // Extract product details from the page
        const products = document.querySelectorAll('.order-table li');
        let productDetails = '';
        products.forEach((product, index) => {
            if (index !== products.length - 2 && index !== products.length - 1) { // Exclude 'Subtotal' and 'Total'
                productDetails += product.textContent.trim() + '. ';
            }
        });

        // Construct the message
        const message = `The products you ordered are ${productDetails} The total price is <?php echo total_price(); ?> Rupees. Please press J to check out.`;

        // Using SpeechSynthesis API to speak out the message
        const utterance = new SpeechSynthesisUtterance(message);
        speechSynthesis.speak(utterance);
    }

    // Call the function to announce product details when the page loads
    window.onload = announceProductDetails;



// Call the function to announce product details when the page loads
window.onload = announceProductDetails;

// Event listener to redirect to checkout page when 'j' key is pressed
document.addEventListener('keydown', function(event) {
    if (event.key === 'j' || event.key === 'J') {
        // Redirect to checkout page
        window.location.href = document.getElementById('placeOrderBtn').href;
    }
});




</script>




</body>

</html>


<?php


if (isset($_GET['place'])) {


    $c_id = $_SESSION['customer_email'];

    $query = "select * from customer where customer_email= '$c_id'";

    $run_query = mysqli_query($con, $query);


    $get_query = mysqli_fetch_array($run_query);

    $custom_id = $get_query['customer_id'];


    $get_items = "select * from cart where c_id = '$c_id'";
    $run_items = mysqli_query($db, $get_items);

    while ($row_items = mysqli_fetch_array($run_items)) {
        $p_id = $row_items['products_id'];
        $pro_qty = $row_items['qty'];

        $get_item = "select * from products where products_id = '$p_id'";
        $run_item = mysqli_query($db, $get_item);

        while ($row_item = mysqli_fetch_array($run_item)) {

            $pro_price = $row_item['product_price'];

            $total_q += $pro_qty;
            $pro_total_p = $pro_price * $pro_qty;
        }

        $final_price += $pro_total_p;
    }
    $order = "insert into orders (order_qty, order_price, c_id, date) values ('$total_q','$final_price','$custom_id',NOW())";

    $run_order = mysqli_query($con, $order);


    $cart_clear = "delete from cart where c_id = '$c_id'";

    $run_clear = mysqli_query($con, $cart_clear);

    echo "<script>alert('Order Placed. Thankyou for Shopping')</script>";
    echo "<script>window.open('account.php?orders','_self')</script>";
}







?>