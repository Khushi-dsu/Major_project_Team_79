
<?php
$active = "Login";
include("db.php");
include("functions.php");
?>


<!-- Breadcrumb Form Section Begin -->

<!-- Register Section Begin -->
<div class="register-login-section spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <div class="login-form">
                    <h2>Login</h2>
                    <form id="loginform" action="login.php" method="post">
                        <div class="group-input">
                            <label for="username">Email</label>
                            <input type="text" id="username" name="cemail" required>
                            <div id="email_error"></div>
                        </div>
                        <div class="group-input">
                            <label for="pass">Password</label>
                            <input type="password" id="pass" name="password" required>
                            <div id="password_error"></div>
                        </div>
                        <div class="log">
                          <h6 style="color:#ffff">T</h6>
                        </div>


                        <button type="submit" name="login" class="site-btn login-btn">Sign In</button>
                    </form>
                    <div class="switch-login">
                        <a href="register.php" class="or-login">Or Create An Account</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Register Form Section End -->

<?php

include("header.php");
?>
<!-- Breadcrumb Section Begin -->
<div class="breacrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text">
                    <a href="index.php"><i class="fa fa-home"></i> Home</a>
                    <span>Login</span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>

<script>

function announceCartPage() {
        const message1 = "press tab to enter your login details or press j if u r a new user";
        // Using SpeechSynthesis API to speak out the message
        const utterance1 = new SpeechSynthesisUtterance(message1);
        speechSynthesis.speak(utterance1);
    }

    // Call the function when the page loads
    window.onload = announceCartPage;

    const speechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new speechRecognition();

    recognition.lang = 'en-US';
    recognition.interimResults = false;

    const speak = (text) => {
        const synth = window.speechSynthesis;
        const utterance = new SpeechSynthesisUtterance(text);
        synth.speak(utterance);
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const lastElement = document.activeElement;

        if (lastElement.tagName === 'INPUT') {
            lastElement.value = transcript;
        }
    };

    recognition.onend = () => {
        console.log('Speech recognition ended.');
    };

    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('focus', () => {
            speak(`Please enter your ${input.previousElementSibling.textContent} and press tab`);
        });
    });

    // Add event listener to the password input field
    const passwordInput = document.getElementById('pass');
    passwordInput.addEventListener('input', (event) => {
        const password = event.target.value;
        if (password.length === 4) {
            const email = document.getElementById('username').value;
            setTimeout(() => {
                speak(`The email is ${email} and the password is ${password} please press enter to proceed`);
            }, 3000); // 3 seconds delay
        }
    });

    document.body.addEventListener('click', () => {
        recognition.start();
    });


    document.addEventListener('keydown', function(event) {
    if (event.key === 'j') {
        window.location.href = 'register.php';
    }
});



document.addEventListener('DOMContentLoaded', function() {
    if (typeof errorMessage !== 'undefined') {
        speak(errorMessage + ', please enter again.');
    }
});




</script>

</body>

</html>

<?php

if (isset($_POST['login'])) {
    $log_email = $_POST['cemail'];
    $log_pass = $_POST['password'];
    $c_id = $log_email;

    $sel_customer = "select * from customer where customer_email = '$log_email' AND customer_pass = '$log_pass'";
    $run_sel_c = mysqli_query($con, $sel_customer);
    $get_ip = getRealIpUser();
    $check_customer = mysqli_num_rows($run_sel_c);
    $select_cart = "select * from cart where c_id = '$c_id'";
    $run_sel_cart = mysqli_query($con, $select_cart);
    $check_cart = mysqli_num_rows($run_sel_cart);

    if ($check_customer == 0) {
        echo "
        <script>
            var errorMessage = 'Invalid Username or Password';
        </script>";
        exit();
    }
    

    if ($check_customer == 1 and $check_cart == 0) {
        $_SESSION['customer_email'] = $log_email;
        echo "<script>window.open('index.php?stat=1','_self')</script>";
    } else {
        $_SESSION['customer_email'] = $log_email;
        echo "<script>window.open('shopping-cart.php?','_self')</script>";
    }
}
?>
