<?php
$active = "upipayment";
include("functions.php");
?>


<div class="upi-container">
    <div class="right">
        <h3>PAYMENT</h3>
        <form>
            <label for="upi_id">Enter UPI ID</label>
            <input type="text" id="upi_id" name="upi_id" placeholder="Enter your UPI ID">
        </form>
        <button id="proceed_btn">Proceed to Pay</button>
    </div>
</div>

<div class="breacrumb-section">
    <div class="containerp">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-text product-more">
                    <a href="index.php"><i class="fa fa-home"></i> Home</a>
                    <a href="shop.php">Shop</a>
                    <a href="payment_mode.php">Select Payment Method</a>
                    <span>UPI Payment</span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include("header.php");
?>
<?php include('footer.php'); ?>






<script>

function announceCartPage() {
        const message1 = "press tab to enter your UPI ID";
        // Using SpeechSynthesis API to speak out the message
        const utterance1 = new SpeechSynthesisUtterance(message1);
        speechSynthesis.speak(utterance1);
    }

    window.onload = announceCartPage;

    // Function to speak out the UPI ID when the "Proceed to Pay" button is clicked
    document.getElementById('proceed_btn').addEventListener('click', function() {
        const upiId = document.getElementById('upi_id').value;
        const message = `The ID is ${upiId} . enter j to check-out`;
        const utterance = new SpeechSynthesisUtterance(message);
        speechSynthesis.speak(utterance);
    });

  



    document.addEventListener('keydown', function(event) {
    if (event.key === 'j') {
        window.location.href = 'ordersuccess.php';
    }
});
</script>

</body>
</html>